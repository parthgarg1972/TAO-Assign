1. First install node js and the install the following packages: request, express, npm, body-parser
2. execute server.js
3. open the index.htm in localhost in any browser, enter the city details and refresh the page after 10 seconds
IMPORTANT NOTE: Please refresh the page 10sec after you have submitted the query to view the results on google maps