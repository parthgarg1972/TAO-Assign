var express = require('express');
var app = express();
var city_id;
var entity_type;
var string1
app.use(express.static('public'));

app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "index.htm" );
})

app.get('/process_get', function (req, res) {

	var city;
    response = {
      city_name:req.query.city_name
    };
   
    city = response["city_name"]
    console.log(city);
   
	var Request = require("request");
	const ZOMATO_KEY = 'e9ca9491cf97ad8cce4608561257f6b0';
	const util = require('util');
	const fs = require('fs');
	
	function query2(string){
	Request.get(string, {
    headers: {
      'user-key': ZOMATO_KEY,
      'Accept':'application/json'
    }
	}, (error, response, body) => {
    if(error) {
        return console.log(error);
    }
    //console.log(util.inspect(JSON.parse(body),false, null, true));
	//console.log(string);
	fs.writeFile('./public/data.json', JSON.stringify(JSON.parse(body),null,4) , function (err) {
    if (err) {
        console.log("An error occured while writing JSON Object to File.");
        return console.log(err);
    }
 
    console.log("JSON file has been saved.");
	});

	}); 	
	}
	
	Request.get('https://developers.zomato.com/api/v2.1/locations?query='+city, {
		headers: {
		'user-key': ZOMATO_KEY,
		'Accept':'application/json'
		}
	}, (error, response, body) => {
    if(error) {
        return console.log(error);
    }
    //console.log(JSON.parse(body));
	
	var json_obj = JSON.parse(body);
	//console.log(json_obj);
	
	city_id = json_obj.location_suggestions[0].entity_id;
	entity_type = json_obj.location_suggestions[0].entity_type;
	string1 = 'https://developers.zomato.com/api/v2.1/search?entity_id='+city_id+'&entity_type='+entity_type
	query2(string1);
	}); 
	
	res.redirect("./index.htm");
	//res.end(JSON.stringify(response));
	//res.render('index');
	//res.render("C:/Users/Aditya Jadhav/Downloads/onto_assign2/index.html");
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})

