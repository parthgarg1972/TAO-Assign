from lxml import etree
import xlrd

wb = xlrd.open_workbook("data.xlsx")
sh = wb.sheet_by_index(0)

country = etree.Element('country')
country.set('country_id','IN')
country_name = etree.SubElement(country, 'country_name')
country_name.text = 'India'
country_area = etree.SubElement(country, 'country_area')
country_capital = etree.SubElement(country, 'country_capital')

row = 0
while row<sh.nrows:
    state_found=False
    val = sh.row_values(row)
    if str(val[3])=="STATE" and str(val[5])=="Total":
        state = etree.SubElement(country,'state')
        state.set('state_id','S'+str(val[0]))
        state.set('is_coastal_area_present','no')
        state_name = etree.SubElement(state, 'state_name')
        state_name.text = str(val[4])
        state_capital = etree.SubElement(state, 'state_capital')
        state_language = etree.SubElement(state, 'state_language')
        state_neighbours = etree.SubElement(state, 'state_neighbours')
        row+=1
        while row<sh.nrows:
            district_found=False
            val = sh.row_values(row)
            if str(val[3])=="STATE" and str(val[5])=="Total":
                state_found=True
                break
            if str(val[3])=="DISTRICT" and str(val[5])=="Total":
                district = etree.SubElement(state,'district')
                district.set('district_id','D'+str(val[1]))
                district_name = etree.SubElement(district, 'district_name')
                district_name.text = str(val[4])
                row+=1
                while row<sh.nrows:
                    val=sh.row_values(row)
                    if str(val[3])=="STATE" and str(val[5])=="Total":
                        state_found=True
                        break
                    if str(val[3])=="DISTRICT" and str(val[5])=="Total":
                        district_found=True
                        break
                    if str(val[3])=="SUB-DISTRICT" and str(val[5])=="Total":
                        val_rural = sh.row_values(row+1)
                        val_urban = sh.row_values(row+2)
                        sub_district = etree.SubElement(district, 'sub_district')
                        sub_district.set('sub_district_id','SD'+str(val[2]))
                        sub_district_name = etree.SubElement(sub_district,'sub_district_name')
                        sub_district_name.text = str(val[4])

                        rural = etree.SubElement(sub_district, 'rural')
                        number_of_villages = etree.SubElement(rural, 'number_of_villages')
                        number_of_villages.text = str(int(val_rural[6]+val_rural[7]))
                        population = etree.SubElement(rural, 'population')
                        male = etree.SubElement(population, 'male')
                        male.text = str(int(val_rural[11]))
                        female = etree.SubElement(population, 'female')
                        female.text = str(int(val_rural[12]))
                        area = etree.SubElement(rural, 'area')
                        area.text = str(val_rural[13])
                        no_of_households = etree.SubElement(rural, 'no_of_households')
                        no_of_households.text = str(int(val_rural[9]))

                        urban = etree.SubElement(sub_district, 'urban')
                        number_of_towns = etree.SubElement(urban, 'no_of_towns')
                        number_of_towns.text = str(int(val_urban[8]))
                        population = etree.SubElement(urban, 'population')
                        male = etree.SubElement(population, 'male')
                        male.text = str(int(val_urban[11]))
                        female = etree.SubElement(population, 'female')
                        female.text = str(int(val_urban[12]))
                        area = etree.SubElement(urban, 'area')
                        area.text = str(val_urban[13])
                        no_of_households = etree.SubElement(urban, 'no_of_households')
                        no_of_households.text = str(int(val_urban[9]))
                        
                    row+=1
            if state_found==True:
                break
            if district_found==False:
                row+=1
    if state_found==False:
        row+=1

text_file = open("Output1.xml", "wb")
text_file.write(etree.tostring(country,pretty_print=True))
text_file.close()
